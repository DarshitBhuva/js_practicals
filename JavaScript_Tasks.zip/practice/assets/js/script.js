let tasks = [{
    taskName: "Assignment",
    description: "Complete assignment",
    status: "Pending",
    startDate: "2020-10-20",
    endDate: "2020-10-25",
    assignedTo: "Raj"
}]

$(document).ready(function () {

    $("#status").select2({
        placeholder: "Select Status",
        height: "100vh",
    });

    $("#assignTo").select2({
        placeholder: "Select Assigned To",
        height: "100vh",
    });
    const table = $("#taskTable").DataTable({
        columnDefs: [
            {
                className: "dt-control",
                orderable: false,
                targets: 0,
            },
            {
                orderable: false,
                targets: [4,5],
            }
        ],
        order: [[1, "asc"]],
    });

    $("#taskTable tbody").on("click", "td.dt-control", function () {
        var tr = $(this).closest("tr");
        var row = table.row(tr);

        if (row.child.isShown()) {
            row.child.hide();
            tr.removeClass("shown");
        }
        else {
            row.child(createRow(row.data())).show();
            tr.addClass("shown");
        }
    })

    displayData();
})

function createRow(data) {
    console.log(data);
    const task = tasks[data[1] - 1];
    let row = `<table class="table table-bordered table-striped table-hover" id="studentData">
                      <thead class="table-dark text-nowrap">
                          <tr>
                              <th>Start Date</th>
                              <th>End Date</th>
                              <th>Assigned To</th>
                          </tr>
                      </thead>
                      <tbody>
                        <tr>
                        <td>${task.startDate}</td>
                        <td>${task.endDate}</td>
                        <td>${task.assignedTo}</td>
                        </tr>
                    </tbody>
            </table>`;
    return row;

}


const displayData = () => {
    let table = $("#taskTable").DataTable();
    table.clear();

    if(!tasks.length)
        return table.rows.add([]).draw();

    tasks.forEach((task, ind) => {
        table.row.add([
            "",
            ind+1,
            task.taskName,
            task.description,
            task.status,
            `<button onclick="deleteTask(${ind})" class="btn btn-danger">Delete</button>
            <button onclick="updateTask(${ind})" class="btn btn-primary">Edit</button>`,
        ]).draw();
    });
}

function onformSubmit(e) {
    e.preventDefault();

    const task = {
        taskName: $("#tname").val(),
        description: $("#desc").val(),
        status: $("#status").val(),
        startDate: $("#sdate").val(),
        endDate: $("#edate").val(),
        assignedTo: $("#assignTo").val()
    }
    console.log(task);
    tasks.push(task);
    $("#taskForm")[0].reset();
    $("#taskForm").find("select").val(null).trigger("change");
    displayData();
}

function deleteTask(ind) {
    let ans = confirm("Are you sure you want to delete the record?");

    if (ans) {
        tasks.splice(ind, 1);
        displayData();
    }
}

function updateTask(ind) {
    const task = tasks[ind];

    $("#submitBtn").val("Update");
    let form = document.getElementById("taskForm");
    form.onsubmit = function (e){
        e.preventDefault();
        onUpdateTask(ind);
    }

    $("#tname").val(task.taskName);
    $("#desc").val(task.description);
    $("#status").val(task.status).trigger("change");
    $("#sdate").val(task.startDate);
    $("#edate").val(task.endDate);
    $("#assignTo").val(task.assignedTo).trigger("change");
}

function onUpdateTask(ind){
    let task = tasks[ind];

    task.taskName = $("#tname").val();
    task.description = $("#desc").val();
    task.status = $("#status").val();
    task.startDate = $("#sdate").val();
    task.endDate = $("#edate").val();
    task.assignedTo = $("#assignTo").val();


    alert("Updated");
    $("#taskForm")[0].reset();
    $("#taskForm").find("select").val(null).trigger("change");
    displayData();
}