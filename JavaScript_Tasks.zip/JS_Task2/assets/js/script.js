let students = [{
    "firstName": "Raj",
    "lastName": "Patel",
    "dob": "2014-01-01",
    "email": "raj1@gmail.com",
    "address": "Mumbai, Maharastra",
    "graduationYear": "2024-05",
    "education": [
        {
            "degree": "Science",
            "college": "A Success",
            "startDate": "2018-06-06",
            "passoutYear": "2020-03",
            "percentage": "80",
            "backlog": "0"
        },
        {
            "degree": "BTech",
            "college": "DDU",
            "startDate": "2020-10-20",
            "passoutYear": "2024-05",
            "percentage": "75",
            "backlog": "0"
        },
        {
            "degree": "10th",
            "college": "Ankur",
            "startDate": "2020-10-20",
            "passoutYear": "2024-05",
            "percentage": "75",
            "backlog": "0"
        },
        {
            "degree": "9th",
            "college": "Ankur",
            "startDate": "2020-10-20",
            "passoutYear": "2024-05",
            "percentage": "75",
            "backlog": "0"
        }
    ]
}];

function onFormSubmit(e) {
    e.preventDefault();

    if (!validateFormData()) {
        return;
    }

    const studentData = {
        firstName: $("#fname").val(),
        lastName: $("#lname").val(),
        dob: $("#dob").val(),
        email: $("#email").val(),
        address: $("#address").val(),
        graduationYear: $("#graduationYear").val(),
        education: [],
    }

    $(".education-group").each(function () {
        const educationdata = {
            degree: $(this).find("input[name='degree']").val(),
            college: $(this).find("input[name='college']").val(),
            startDate: $(this).find("input[name='startDate']").val(),
            passoutYear: $(this).find("input[name='passoutYear']").val(),
            percentage: $(this).find("input[name='percentage']").val(),
            backlog: $(this).find("input[name='backlog']").val(),
        }

        studentData.education.push(educationdata);
    })

    students.push(studentData);
    alert("Sudent Added Successfully!")

    displayData();
}

const displayData = () => {

    const table = $("#example").DataTable();
    table.clear();

    if (!students.length) {
        return table.rows.add([]).draw();
    }

    students.forEach((student, ind) => {
        table.row.add([
            "",
            ind + 1,
            student.firstName,
            student.lastName,
            student.dob,
            student.email,
            student.address,
            student.graduationYear,
            `<div class="d-flex"><button class="btn" onclick="updateStudent(${ind})"><i class="bi bi-pencil-fill"></i></button>
            <button class="btn" onclick="deleteStudent(${ind})"><i class="bi bi-trash-fill"></i></button></div>`
        ]).draw();
    })
}

function getChildRow(data) {
    const student = students[data[1] - 1];
    let row = `<table class="table table-bordered table-striped table-hover" id="studentData">
                      <thead class="table-dark text-nowrap">
                          <tr>
                              <th>Sr no.</th>
                              <th>Degree/Board</th>
                              <th>School/College</th>
                              <th>Start Date</th>
                              <th>Passout Year</th>
                              <th>Percentage</th>
                              <th>Backlog</th>
                          </tr>
                      </thead>
                      <tbody>`;
    if (student.education.length <= 0) {
        row += `<tr>
                    <td colspan="7" class="text-center">No Education Data Found</td>
                </tr>`;
    } else {
        student.education.forEach((education, index) => {
            row += `<tr>
                        <td>${index + 1}</td>
                        <td>${education.degree}</td>
                        <td>${education.college}</td>
                        <td>${education.startDate}</td>
                        <td>${education.passoutYear}</td>
                        <td>${education.percentage}</td>
                        <td>${education.backlog}</td>
                    </tr>`;
        });
    }
    row += `</tbody>
            </table>`;
    return row;
}

$(document).ready(function () {
    const table = $("#example").DataTable({
        columnDefs: [
            {
                className: "dt-control",
                orderable: false,
                targets: 0,
            },
            {
                orderable: false,
                targets: 8,
            },
        ],
        order: [[1, "asc"]],
    });


    $("#example tbody").on("click", "td.dt-control", function () {
        var tr = $(this).closest("tr");
        var row = table.row(tr);

        if (row.child.isShown()) {
            row.child.hide();
            tr.removeClass("shown");
        } else {
            row.child(getChildRow(row.data())).show();
            tr.addClass("shown");
        }
    });

    displayData();


})

function validateDates(startDate, endDate) {

    // startDate : YYYY-MM-DD
    // endDate : YYYY-MM
    let sdate = startDate.split("-");
    let edate = endDate.split("-");

    if (sdate[0] > edate[0])
        return false;

    if (sdate[0] == edate[0] && sdate[1] > edate[1])
        return false;

    return true;
}

function validateTextInput() {

    let isValid = true;
    $('input[type="text"]').each(function () {
        let value = $(this).val();

        let isOnlyNumbers = /^\d+$/.test(value);

        let containsLetter = /[a-zA-Z]/.test(value);

        let containsNegative = /^-/.test(value);


        if ($(this).hasClass("is-invalid")) {
            $(this).removeClass("is-invalid");
            $(this).next("small.text-danger").remove();
        }

        if (containsNegative) {
            isValid = false;
            $(this).addClass("is-invalid");
            $(this).after(`<small class='text-danger'>* This field should not contain negative number </small>`)
        }
        else if (isOnlyNumbers || !containsLetter) {
            isValid = false;
            $(this).addClass("is-invalid");
            $(this).after("<small class='text-danger'>* Insert atleat one character</small>")
        }

        if ($(this).hasClass("college") || $(this).hasClass("name")) {

            let isContainLetter = /[0-9]/.test(value);
            if (isContainLetter) {
                isValid = false;
                $(this).addClass("is-invalid");
                $(this).after("<small class='text-danger'>* Numbers is not allowed</small>")
            }

            if ($(this).hasClass("name") && /\s/.test(value)) {
                isValid = false;
                $(this).addClass("is-invalid");
                $(this).after("<small class='text-danger'>* Space is not allowed</small>")
            }
        }

    })
    return isValid;
}

function validateFormData() {

    let isValid = true;

    if ($("#dob").hasClass("is-invalid")) {
        $("#dob").removeClass("is-invalid");
        $("#dob").next("small.text-danger").remove();
    }
    if (!validateDates($("#dob").val(), $("#graduationYear").val())) {
        $("#dob").addClass("is-invalid");
        $("#dob").after("<small class='text-danger'>* DOB must before the Graduation Year</small>");
        isValid = false;
    }


    $(".education-group").each(function () {
        let startDate = $(this).find("input[name='startDate']");
        let passoutYear = $(this).find("input[name='passoutYear']");

        if (startDate.hasClass("is-invalid")) {
            startDate.removeClass("is-invalid");
            startDate.next("small.text-danger").remove();
        }

        if (!validateDates(startDate.val(), passoutYear.val())) {
            isValid = false;
            startDate.addClass("is-invalid");
            startDate.after("<small class='text-danger'>* Start date must be before passout year</small>");
        }
    })

    if (!validateTextInput())
        isValid = false;

    return isValid;


}
const addEducationSection = () => {
    const education = $(".education-group").html();
    const ind = $(".education-group").length;
    const row = $(`<div class='row education-group' id='education-group${ind}'></div>`);
    row.append(education);
    row.append(`<div class="col-md-1 col-sm-12 mb-3"><button type="button" onclick="removeEducationSection(${ind})" class="btn nav-link link-dark"><i class="bi bi-dash-circle-fill fs-3"></i></button></div>`);
    $(".education").append(row);
}

const removeEducationSection = (ind) => {
    const education = $(".education-group");
    education.remove(`#education-group${ind}`);
}

const deleteStudent = (ind) => {
    let ans = confirm("Are you sure you want to delete the record?");

    if (ans) {
        students.splice(ind, 1);
        displayData();
    }
}

const updateStudent = (ind) => {
    const student = students[ind];
    $("#submitBtn").val("Update");
    const form = document.getElementById('studentDetailForm');
    form.onsubmit = function (e) {
        e.preventDefault();
        onUpdateStudent(ind)
    };
    $("#fname").val(student.firstName);
    $("#lname").val(student.lastName);
    $("#dob").val(student.dob);
    $("#email").val(student.email);
    $("#address").val(student.address);
    $("#graduationYear").val(student.graduationYear);

    let educationLen = student.education.length;
    console.log(educationLen);

    if (educationLen > 0) {

        if ($(".education-group").length !== educationLen) {
            while (educationLen > 2) {
                addEducationSection();
                educationLen--;
            }
        }

        $(".education-group").each(function (ind) {
            $(this).find("input[name='degree']").val(student.education[ind].degree);
            $(this).find("input[name='college']").val(student.education[ind].college);
            $(this).find("input[name='startDate']").val(student.education[ind].startDate);
            $(this).find("input[name='passoutYear']").val(student.education[ind].passoutYear);
            $(this).find("input[name='percentage']").val(student.education[ind].percentage);
            $(this).find("input[name='backlog']").val(student.education[ind].backlog);
        })

    }

}

function onUpdateStudent(ind) {

    if (!validateFormData()) {
        return;
    }

    let student = students[ind];

    student.firstName = $("#fname").val();
    student.lastName = $("#lname").val();
    student.dob = $("#dob").val();
    student.email = $("#email").val();
    student.address = $("#address").val();
    student.graduationYear = $("#graduationYear").val();

    student.education = [];

    $(".education-group").each(function (ind) {

        const educationData = {
            degree: $(this).find("input[name='degree']").val(),
            college: $(this).find("input[name='college']").val(),
            startDate: $(this).find("input[name='startDate']").val(),
            passoutYear: $(this).find("input[name='passoutYear']").val(),
            percentage: $(this).find("input[name='percentage']").val(),
            backlog: $(this).find("input[name='backlog']").val(),
        }

        student.education.push(educationData);
    });

    showAlertMessage("Student Updated Successfully");
    $("#submitBtn").val("Submit");
    const form = document.getElementById('studentDetailForm');
    form.onsubmit = function (e) {
        onFormSubmit(e)
    };
    displayData();
}

const showAlertMessage = (message) => {
    let notification = $(".notification");
    const alert = $(`<div class="alert alert-primary alert-dismissible fade show" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <strong>${message}</strong>
    </div>
`);

    notification.append(alert);
}