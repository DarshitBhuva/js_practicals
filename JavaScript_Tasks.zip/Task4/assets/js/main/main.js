let mainData = [];

function addNewEmployee(e) {
  e.preventDefault();
  if (!$("#chargeForm").valid()) return;
  const emp_data = {
    firstName: $("#firstName").val().trim(),
    middleName: $("#middleName").val().trim(),
    lastName: $("#lastName").val().trim(),
    email: $("#email").val().trim(),
    dob: $("#dob").val(),
    gender: $("input[name='gender']:checked").val(),
    personalDetails: [],
  };
  $(".personal-data").each(function () {
    const Details = {
      role: $(this).find("select[name='role[]']").val(),
      technology: $(this).find("select[name='technology[]']").val(),
      salary: $(this).find("input[id='salary']").val().trim(),
      phoneNumber: $(this).find("input[name='phoneNumber[]']").val().trim(),
      address: $(this).find("input[name='address[]']").val().trim(),
      nationality: $(this).find("select[name='nationality[]']").val(),
      language: $(this)
        .find("input[name='language[]']:checked")
        .map(function () {
          return $(this).val();
        })
        .get(),
    };


    emp_data.personalDetails.push(Details);
  });
  mainData.push(emp_data);
  importData();
  closeForm();
}
function closeForm() {
  $("form").trigger("reset");
  $("#chargeForm").find("select").val(null).trigger("change");
  $("#chargeForm")
    .off("submit")
    .on("submit", function (e) {
      addNewEmployee(e);
    });
  $(".modal").modal("hide");
  $("#submit-btn").show();
  $("#update-btn").remove();
}
function importData() {
  let table = $("#employeeTable").DataTable();
  table.clear();
  let totalSalaries = 0;
  let totalEmployees = mainData.length;
  if (mainData.length > 0) {
    mainData.forEach((employee, index) => {
      table.row
        .add([
          "",
          index + 1,
          employee.firstName,
          employee.middleName,
          employee.lastName,
          employee.email,
          employee.dob,
          employee.gender,
          `<div class="d-flex gap-2">
            <button class="border-0" onclick="editEmployeeData(${index})" id="view-btn"><i class="bi bi-pencil-square"></i></button>
            <button class="border-0" onclick="deleteEmployeeData(${index})" id="view-btn"><i class="bi bi-trash"></i></button>
          </div>`,
        ])
        .draw();
      totalSalaries += parseInt(employee.personalDetails[0].salary);
    });
  } else {
    table.clear().draw();
  }
  $("#total-salary").text(`${totalSalaries}`);
  $("#totalEmployees").text(`${totalEmployees}`);
}

const editEmployeeData = (index) => {
  if (!$("#chargeForm").valid()) return;
  $(".modal").modal("show");
  const employee = mainData[index];
  $("#firstName").val(employee.firstName);
  $("#middleName").val(employee.middleName);
  $("#lastName").val(employee.lastName);
  $("#email").val(employee.email);
  $("#gender").val(employee.gender);
  employee.personalDetails.forEach((details, index) => {
    $("#role").val(details.role);
    $("#technology").val(details.technology);
    $("#salary").val(details.salary);
    $("#phoneNumber").val(details.phoneNumber);
    $("#address").val(details.address);
    $("#nationality").val(details.nationality);
    $("#language").prop("checked", false);
    details.language.forEach((language) => {
      $("input").prop("checked", true);
    });
  });
  $("#submit-btn").hide();
  const updateButton = `<button type="button" class="btn btn-primary d-block mx-auto" id="update-btn">Update</button>`;
  $("#chargeForm").append(updateButton);
  $("#update-btn").click(() => {
    const updateEmployeeData = {
      firstName: $("#firstName").val().trim(),
      middleName: $("#middleName").val().trim(),
      lastName: $("#lastName").val().trim(),
      email: $("#email").val().trim(),
      dob: $("#dob").val(),
      gender: $("input[name='gender']:checked").val(),
      personalDetails: [],
    };
    $(".personal-data").each(function () {
      const Details = {
        role: $(this).find("select[name='role[]']").val(),
        technology: $(this).find("select[name='technology[]']").val(),
        salary: $(this).find("input[name='salary[]']").val().trim(),
        phoneNumber: $(this).find("input[name='phoneNumber[]']").val().trim(),
        address: $(this).find("input[name='address[]']").val().trim(),
        nationality: $(this).find("select[name='nationality[]']").val(),
        language: $(this)
          .find("input[name='language[]']:checked")
          .map(function () {
            return $(this).val();
          })
          .get(),
      };
      updateEmployeeData.personalDetails.push(Detail);
    });
    mainData[index] = updateEmployeeData;
    importData();
    closeForm();
  });
};
function deleteEmployeeData(index) {
  const isConfirmed = confirm("Are you sure you want to delete?");
  if (isConfirmed) {
    mainData.splice(index, 1);
    importData();
  }
}
function getChildRow(data) {
  let employee = mainData[data[1] - 1];
  let row = `<table class="table table-bordered table-striped table-hover" id="studentData">
              <thead class="table-success text-nowrap">
                <tr>
                  <th>Sr no.</th>
                  <th>Role</th>
                  <th>Technology</th>
                  <th>Salary</th>
                  <th>Phone Number</th>
                  <th>Address</th>
                  <th>Nationality</th>
                  <th>Language</th>
                </tr>
              </thead>
              <tbody>`;
  if (employee.personalDetails.length <= 0) {
    row += `<tr>
              <td colspan="8" class="text-center">No Education Data Found</td>
            </tr>`;
  } else {
    employee.personalDetails.forEach((personalDetails, index) => {
      row += `<tr>
                <td>${index + 1}</td>
                <td>${personalDetails.role}</td>
                <td>${personalDetails.technology}</td>
                <td>${personalDetails.salary}</td>
                <td>${personalDetails.phoneNumber}</td>
                <td>${personalDetails.address}</td>
                <td>${personalDetails.nationality}</td>
                <td>${personalDetails.language}</td>
              </tr>`;
    });
  }
  row += `</tbody>
  </table>`;
  return row;
}
$(document).ready(function () {
  let table = $("#employeeTable").DataTable({
    scrollX: true,
    columnDefs: [
      {
        className: "dt-control",
        defaultContent: "",
        orderable: false,
        targets: 0,
      },
      {
        orderable: false,
        targets: 5,
        defaultContent: "",
      },
      {
        orderable: false,
        targets: 6,
        defaultContent: "",
      },
      {
        orderable: false,
        targets: 8,
        defaultContent: "",
      },
      {
        targets: [1, 2, 3, 4, 6],
        defaultContent: "",
      },
    ],
    order: [[1, "asc"]],
  });
  $("#employeeTable tbody").on("click", "td.dt-control", function () {
    var tr = $(this).closest("tr");
    var row = table.row(tr);

    if (row.child.isShown()) {
      row.child.hide();
      tr.removeClass("shown");
    } else {
      row.child(getChildRow(row.data())).show();
      tr.addClass("shown");
    }
  });
  $("#role").select2({
    dropdownParent: $("#role").parent(),
    placeholder: "Select Role",
    width: "100%",
  });

  $.validator.addMethod("noNumbers", function (value, element) {
    return this.optional(element) || !/\d/.test(value);
  }, "First name must not contain any numbers");

  $("#technology").select2({
    dropdownParent: $("#technology").parent(),
    placeholder: "Select technology",
    width: "100%",
  });
  $("#nationality").select2({
    dropdownParent: $("#nationality").parent(),
    placeholder: "Select nationality",
    width: "100%",
  });
  $("#chargeForm").validate({
    errorElement: "div",
    errorPlacement: function (error, element) {
      error.addClass("invalid-feedback");
      element.closest(".form-group").append(error);
    },
    rules: {
      firstName: {
        required: true,
        minlength: 3,
        noNumbers: true,
      },
      lastName: {
        required: true,
        minlength: 3,
      },
      middleName: {
        required: true,
        minlength: 3,
      },
      email: {
        required: true,
        email: true,
      },
      dob: {
        required: true,
        date: true,
      },
      gender: {
        required: true,
      },
      "role[]": {
        required: true,
      },
      "technology[]": {
        required: true,
      },
      "salary[]": {
        required: true,
        number: true,
      },
      "phoneNumber[]": {
        required: true,
        minlength: 10,
        maxlength: 10,
        digits: true,
      },
      "address[]": {
        required: true,
        minlength: 5,
      },
      "nationality[]": {
        required: true,
      },
      "language[]": {
        required: true,
      },
    },
    messages: {
      firstName: {
        required: "First Name is required",
        minlength: "First Name should be at least 3 characters long",

      },
      lastName: {
        required: "Last Name is required",
        minlength: "Last Name should be at least 3 characters long",
      },
      middleName: {
        required: "Middle Name is required",
        minlength: "Middle Name should be at least 3 characters long",
      },
      email: {
        required: "Email is required",
        email: "Please enter a valid email address",
      },
      dob: {
        required: "Date of Birth is required",
        date: "Please enter a valid date",
      },
      gender: {
        required: "Please select a gender",
      },
      "role[]": {
        required: "Role is required",
      },
      "technology[]": {
        required: "Technology is required",
      },
      "salary[]": {
        required: "Salary is required",
        number: "Please enter a valid number",
      },
      "phoneNumber[]": {
        required: "Phone number is required",
        minLength: "Phone number should be 10 digits long",
        maxLength: "Phone number should be 10 digits long",
        digits: "Please enter a valid phone number",
      },
      "address[]": {
        required: "Address is required",
        minlength: "Address should be at least 5 characters long",
      },
      "nationality[]": {
        required: "Nationality is required",
      },
      "language[]": {
        required: "Please select at least one language",
      },
    },
  });
  importData();
});
